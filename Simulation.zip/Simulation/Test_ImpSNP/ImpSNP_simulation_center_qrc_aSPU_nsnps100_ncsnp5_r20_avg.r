setwd("D:/Work/lowrank/Rcode/aSPULR")
source("rsvd.R")
source("qrc.R")
source("aSPU0.R")
source("aSPUboot20.R")
source("simPathAR1Snp2.r")

set.seed(100)

a = 0.8
nsnps = c(100)
nsim = 1000
nperm = 1000
nsubject = 500
ncgene = 1
rhos = c(0.8, 0.9)
p0 = 0.1
ngene = 1
ncsnps = 5

r = 20
k = 2

ct = rep(0,ncsnps)
ct1 = 0
li_avg =c()
for (i in 1:nsim){
  if (i %% 10 == 0) {message (i,'   ',date())}
  ## get SNP matrix A
  dat1 <- simPathAR1Snp2(nGenes = ngene, nGenes1 = ncgene, nSNPs = nsnps, ncSNPs = ncsnps,
                         nSNPlim = c(1, ngene), nSNP0 = 1, LOR = a, n = nsubject,
                         MAFlim = c(0.05, 0.4), rholim = rhos, p0 = p0, noncausal = FALSE)
  
  X = dat1$X
  Y = dat1$Y
  
  ## get Q, R from X
  rqr = rsvd(as.matrix(X),r,k)
  Q = rqr$Q
  R = rqr$R
  
  ## center X 
  Xc = scale(X, center = TRUE, scale = FALSE)  ## centered X
  
  n = dim(X)[1]
  Xm = colMeans(X)  ## column mean vector
  Xc1 = qrc(Q,R,Xm,n)  ## get circle Q and circle R (for centered X) from Q and R (for X)
  Qc = Xc1$Qc
  Rc = Xc1$Rc
  
  out0 = qr(Rc, LAPACK=TRUE)
  idx = out0$pivot[1:r]

  ## fisher exact test to find significant snps that are associated with somatic mutation outcome
  pval <- NULL
  for (j in 1:dim(X)[2]){
    ### create 2 by 3 fisher table
    table_data <- cbind(X[,j],Y)
    table23 <- as.matrix(t(table(as.data.frame(table_data))))
    # colnames(table23) <- c("0","1","2")
    # rownames(table23) <- c(0,1)
    
    ### perform fisher exact test 
    model <- fisher.test(table23)
    pval[j] <- model$p.value
  }
  sorted_idx = order(pval)
  smallest_idx = sorted_idx[1:ncsnps]
  
  ## 
  inter = intersect(idx,smallest_idx)
  li = length(inter)
  if (li > 0) ct[li] = ct[li]+1
  
  ##
  smallest_idx1 = sorted_idx[1]
  inter1 = intersect(idx,smallest_idx1)
  li1 = length(inter1)
  if (li1 > 0) ct1 = ct1+1
  
  ## avg
  inter_avg = intersect(idx,smallest_idx)
  li_avg[i] = length(inter_avg)
}

ct       
sum(ct)  
ct1      

mean(li_avg)  