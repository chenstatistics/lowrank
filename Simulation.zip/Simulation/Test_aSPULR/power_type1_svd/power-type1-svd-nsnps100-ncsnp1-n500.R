library("aSPU")
setwd("D:/Work/lowrank/Rcode/aSPULR")
source("aSPUlr.R")
source("aSPUbootlr.R")
source("aSPU0.R")
source("aSPUboot20.R")
source("rsvd.R")
source("simPathAR1Snp2.r")

set.seed(100)

a <- c(0,seq(from = 0.2, to = 0.6, by = 0.1))

nsnps = c(100)

nsim = 1000
nperm = 1000

nsubject = 500
ncgene = 1
rhos = c(0.8, 0.9)
p0 = 0.1

ngene = 1
# ncsnps = c(rep(10,ncgene),rep(0, ngene-ncgene))
ncsnps = 1

g0 = c(1:8,Inf)
# g1 = c(1,2,3,5,Inf)

pwaspu <- c()
pwaspulrpp <- c()
for (i in 1:6){
  pvaspu <- c()
  pvaspulrpp <- c()
  for (j in 1:nsim){
    if (j %% 10 == 0) {message (i,': ', j,'   ',date())}
    dat1 <- simPathAR1Snp2(nGenes = ngene, nGenes1 = ncgene, nSNPs = nsnps, ncSNPs = ncsnps,
                           nSNPlim = c(1, ngene), nSNP0 = 1, LOR = a[i], n = nsubject,
                           MAFlim = c(0.05, 0.4), rholim = rhos, p0 = p0, noncausal = FALSE)
    
    YY = matrix(NA,nsubject,nperm)
    Ym = dat1$Y-mean(dat1$Y)
    for (b in 1:nperm) YY[,b] = sample(Ym, nsubject)
    
    ###### aSPU #####
    out0 <- aSPU0(dat1$Y, YY, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = g0, n.perm = nperm)
    pvaspu[j] <- out0$pvs[length(out0$pvs)]
    
    ###### aSPU-LR
    ## rsvd
    r = floor(min(dim(dat1$X))/5)
    Xt = rsvd(as.matrix(dat1$X),r,k=2)
    tQ = t(Xt$Q)
    tR = t(Xt$R)

    out1 <- aSPUlr(dat1$Y, YY, dat1$X, tQ, tR, cov = NULL, resample = "boot",model = "binomial", pow = g0, n.perm = nperm)
    pvaspulrpp[j] <- out1$pvs[length(out1$pvs)]
  }
  pwaspu[i] <- sum(pvaspu < 0.05)/length(pvaspu)
  pwaspulrpp[i] <- sum(pvaspulrpp < 0.05)/length(pvaspulrpp)
}

## power
par(mar=c(5,5,2,2))
matplot(a[2:6],cbind(pwaspu[2:6],pwaspulrpp[2:6]),type="b",pch=1:2, col=1:2, ylim=c(0,1), xlab = "log OR", ylab = "Power" ,cex=1.8, cex.axis=1.8,cex.lab=1.8,cex.main=1.8)
legend("topleft", inset=0.01, legend=c("aSPU","aSPU-LR"), col=c(1:2),pch=1:2,bg= ("white"), horiz=F,cex=1.5)

## svd
par(mar=c(5,5,2,2))
A.svd <- svd(dat1$X)
plot(A.svd$d,xlab = "Index of SNPs", ylab = "Singular values" ,cex=1.0, cex.axis=1.8,cex.lab=1.8,cex.main=1.8)
