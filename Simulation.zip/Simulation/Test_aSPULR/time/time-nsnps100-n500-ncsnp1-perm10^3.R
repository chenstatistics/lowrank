library("aSPU")
setwd("D:/Work/lowrank/Rcode/aSPULR")
source("aSPUlr.R")
source("aSPUbootlr.R")
source("aSPU0.R")
source("aSPUboot20.R")
source("rsvd.R")
source("simPathAR1Snp2.r")

set.seed(100)

nsnps = c(100)

nsim = 100
nperm = 1000

nsubject = 500
ncgene = 1
rhos = c(0.8, 0.9)
p0 = 0.1

ngene = 1
ncsnps = 1

g0 = c(1:8,Inf)

pvaspu <- c()
pvaspulr <- c()
timeaspu <- c()
timeaspulr <- c()
svd_time <- c()

for (j in 1:nsim){
  if (j %% 10 == 0) {message (j,'   ',date())}
  dat1 <- simPathAR1Snp2(nGenes = ngene, nGenes1 = ncgene, nSNPs = nsnps, ncSNPs = ncsnps,
                         nSNPlim = c(1, ngene), nSNP0 = 1, LOR = 0.2, n = nsubject,
                         MAFlim = c(0.05, 0.4), rholim = rhos, p0 = p0, noncausal = FALSE)
 
  YY = matrix(NA,nsubject,nperm)
  Ym = dat1$Y-mean(dat1$Y)
  for (b in 1:nperm) YY[,b] = sample(Ym, nsubject)
   
  ###### aSPU #####
  t1=Sys.time()
  out0 <- aSPU0(dat1$Y, YY, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = g0, n.perm = nperm)
  t2=Sys.time()
  timeaspu[j] = t2-t1
  pvaspu[j] <- out0$pvs[length(out0$pvs)]
  
  ###### New #####
  ## rsvd
  t01 = Sys.time()
  r = floor(min(dim(dat1$X))/5)
  Xt = rsvd(as.matrix(dat1$X),r,k=1)
  tQ = t(Xt$Q)
  tR = t(Xt$R)
  t02 = Sys.time()  
  svd_time[j] = t02 - t01  ## 
  
  ###### aSPU-LR
  t3=Sys.time()
  out1 <- aSPUlr(dat1$Y, YY, dat1$X, tQ, tR, cov = NULL, resample = "boot",model = "binomial", pow = g0, n.perm = nperm)
  t4=Sys.time()
  timeaspulr[j] = t4-t3
  pvaspulr[j] <- out1$pvs[length(out1$pvs)]
}

## computational cost
# aSPU
sum(timeaspu)  

# aSPU-LR
sum(svd_time+timeaspulr) 

# svd 
sum(svd_time)  

