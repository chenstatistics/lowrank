aSPU0 <- function (Y, YY, X, cov = NULL, resample = c("perm", "boot", "sim"), 
                  model = c("gaussian", "binomial"), pow = c(1:8, Inf), n.perm = 1000, 
                  threshold = 10^5) 
{
  X <- as.matrix(X)
  model <- match.arg(model)
  resample <- match.arg(resample)
  if (resample == "boot") {
    if (n.perm > threshold) {
      aSPUboot(Y = Y, X = X, cov = cov, pow = pow, n.perm = n.perm, 
               model = model)
    }
    else {
      aSPUboot20(Y = Y, YY = YY, X = X, cov = cov, pow = pow, n.perm = n.perm, 
                model = model)
    }
  }
  else {
    if (resample == "sim") {
      if (n.perm > threshold) {
        aSPUsim1(Y = Y, X = X, cov = cov, pow = pow, 
                 n.perm = n.perm, model = model)
      }
      else {
        aSPUsim2(Y = Y, X = X, cov = cov, pow = pow, 
                 n.perm = n.perm, model = model)
      }
    }
    else {
      if (n.perm > threshold) {
        aSPUperm(Y = Y, X = X, cov = cov, pow = pow, 
                 n.perm = n.perm, model = model)
      }
      else {
        aSPUperm2(Y = Y, X = X, cov = cov, pow = pow, 
                  n.perm = n.perm, model = model)
      }
    }
  }
}