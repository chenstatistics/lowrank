core package:

simPathAR1Snp2: simulate SNP and outcome data
rsvd: randomized svd

1) aSPU-LR
aSPU: aSPU0 ---> aSPUboot20
aSPU-LR: aSPUlr ---> aSPUbootlr

2) parameter selection
aSPU0ps -> aSPUbootps
aSPUbootlrps

aSPUboot20anyg can be used for aSPU, but slower. Do NOT use for timing.

3) representative SNPs
qrc: get circle Q and circle R (for centered X) from Q and R (for X)

