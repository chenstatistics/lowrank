rsvd <- function(X,r,k)
{
  #n = 200
  #p = 100
  #X = matrix( rnorm(n*40,mean=0,sd=1), n, 40) %*% matrix( rnorm(p*40,mean=0,sd=1), 40, p);
  
  # ###########
  # s = svd(X)
  # Q = s$u
  # D = s$d
  # V = s$v
  # 
  # r = 10
  # Q1 = Q[,1:r]
  # D1 = diag(D[1:r])
  # V1 = V[,1:r]
  # 
  # Xt = Q1%*%D1%*%t(V1)
  # norm(X-Xt, type ="2")/norm(X, type ="2")
  # ###########
  
  n = dim(X)[1]
  p = dim(X)[2]
  a = 3
  Z = matrix(rnorm(p*(r+a),mean=0,sd=1), p,r+a)
  W = X%*%Z
  
  sW = svd(W)
  
  for (j in 1:k)
  {  W = t(X)%*%sW$u
     sW = svd(W)
     W = X%*%sW$u
     sW = svd(W)
  } 
  
  QW = sW$u
  
  Q = QW[,1:r]
  
  R = t(Q)%*%X
  #Xt1 = Q %*%R
  #norm(X-Xt1, type ="2")/norm(X, type ="2")
  
  Xt = list(Q=Q,R=R)
  return(Xt)
}