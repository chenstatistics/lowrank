aSPU0ps <- function (Y, YY, X, cov = NULL, resample = c("perm", "boot", "sim"), 
          model = c("gaussian", "binomial"), pow, n.perm = 1000) 
{
  require(aSPU)
  X <- as.matrix(X)
  model <- match.arg(model)
  resample <- match.arg(resample)
  if (resample == "boot") {
    if (n.perm > 10^5) {
      aSPUboot(Y = Y, X = X, cov = cov, pow = pow, n.perm = n.perm, 
               model = model)
    }
    else {
      aSPUbootps(Y = Y, YY= YY, X = X, cov = cov, pow = pow, n.perm = n.perm, 
                model = model)
    }
  }
  else {
    if (resample == "sim") {
      if (n.perm > 10^5) {
        aSPUsim1(Y = Y, X = X, cov = cov, pow = pow, 
                 n.perm = n.perm, model = model)
      }
      else {
        aSPUsim2(Y = Y, X = X, cov = cov, pow = pow, 
                 n.perm = n.perm, model = model)
      }
    }
    else {
      if (n.perm > 10^5) {
        aSPUperm(Y = Y, X = X, cov = cov, pow = pow, 
                 n.perm = n.perm, model = model)
      }
      else {
        aSPUperm2(Y = Y, X = X, cov = cov, pow = pow, 
                  n.perm = n.perm, model = model)
      }
    }
  }
}