## aSPU and aSPU-LR computational time and p-values 
## test association between germline SNPs and somatic mutation driver genes 

library(data.table)
library(varhandle)
library("aSPU")

setwd("D:/Work/data")

################################################### X data #########################################################
## read sample id 
tcga_sampleid <- fread("tcga.clean.sampleid", header = FALSE )
icgc_sampleid <- fread("icgc.clean.sampleid", header = FALSE)

## read annotated genes from oncotator 
tcga_oncotator <- fread("oncotator.tcga.useful.uniq.v2", fill = TRUE , header = TRUE)
icgc_oncotator <- fread("oncotator.icgc.useful.uniq.v2",fill = TRUE , header = TRUE)

#############################################################
## read driver gene list 
driver_gene <- read.csv("2019-5-3-driver-gene-toUse.csv")
driver_gene1 <- driver_gene[,-1]
# driver_gene2 <- unfactor(driver_gene1)
#############################################################

tcga_oncotator_driver <- tcga_oncotator[which(tcga_oncotator$Hugo_Symbol %in% driver_gene1),]
tcga_genes = unique(tcga_oncotator_driver$Hugo_Symbol)
# [1] 150

icgc_oncotator_driver <- icgc_oncotator[which(icgc_oncotator$Hugo_Symbol %in% driver_gene1),]
icgc_genes = unique(icgc_oncotator_driver$Hugo_Symbol)
# [1] 150

all.equal(tcga_genes,icgc_genes) # same

all_genes = tcga_genes # same  150

setwd("D:/Work/data/2019-5-8aSPUpvalues")

load("2019-5-8-germlineBRCA1-somaticDriver-association-pvalue.rdata")

nperm = 10000
nsubject = dim(merged_data_i)[1]
X = merged_data_i
Y = somatic_driver_order

############################################ Association test #######################################################
g0 = c(1:8,Inf)
#g1 = c(1,2,3,5,Inf)

setwd("D:/Work/lowrank/Rcode/aSPULR")
source("aSPUlr.R")
source("aSPUbootlr.R")
source("aSPU0.R")
source("aSPUboot20.R")
source("rsvd.R")

timeaspu = c()
timeaspupp = c()

pvaspu <- c()
pvaspupp <- c()


t01 = Sys.time()
r = floor(min(dim(merged_data_i))/5)

k = 2
Xt = rsvd(as.matrix(merged_data_i),r,k)
tQ = t(Xt$Q)
tR = t(Xt$R)
t02 = Sys.time()  
svd_time = t02 - t01  ## 


for (j in 1:length(driver)){
  if (j %% 10 == 0) {message (j,'   ',date())}
  
  YY = matrix(NA,nsubject,nperm)
  Ym = Y[,j]-mean(Y[,j])
  for (b in 1:nperm) YY[,b] = sample(Ym, nsubject)
  
  ###### aSPU
  t1=Sys.time()
  out0 <- aSPU0(Y[,j], YY, X, cov = NULL, resample = "boot",model = "binomial", pow = g0, n.perm = 10000)
  t2=Sys.time()
  timeaspu[j] = t2-t1
  pvaspu[j] <- out0$pvs[length(out0$pvs)]
  
  ###### aSPU-LR
  t3=Sys.time()
  out1 <- aSPUlr(Y[,j], YY, X, tQ, tR, cov = NULL, resample = "boot",model = "binomial", pow = g0, n.perm = 10000)
  t4=Sys.time()
  timeaspupp[j] = t4-t3
  pvaspupp[j] <- out1$pvs[length(out1$pvs)]
}
sum(timeaspu)   
sum(timeaspupp)  

tot.time.aspu = sum(timeaspu)  
tot.time.aspupp = sum(timeaspupp)+svd_time    
svd_time                       

output1 <- data.frame(driver,pvaspu)
output2 <- output1[order(output1$pvaspu),]

output3 <- data.frame(driver,pvaspupp)
output4 <- output3[order(output3$pvaspupp),]

output = data.frame(output2,output4)

data1 <- -log10(output2$pvaspu)
data2 <- -log10(output4$pvaspupp)

par(mar=c(5,5,2,2))
qqplot(data1,data2,xlab="aSPU",ylab="aSPU-LR",cex.axis=1.5,cex.lab=1.5,cex.main=1.5)
# abline(lm(data1~data2),col="red")
abline(a=0, b=1, col="red", lty=1)

dim(merged_data_i)  ## [1] 2561  140
A.svd <- svd(merged_data_i)

par(mar=c(5,5,2,2))
plot(A.svd$d, xlab = "SNP index", ylab = "Sigular values of SNP matrix",
     cex.axis=1.5,cex.lab=1.5,cex.main=1.5)

write.csv(output, file = "2025-4-21-aSPU-LR-perm10^4-pvalue-germlineBRCA1-somaticDriver.csv")
