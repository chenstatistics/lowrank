setwd("D:/Work/data/2019-5-8aSPUpvalues")

## get SNP matrix A
load("2019-5-8-germlineBRCA1-somaticDriver-association-pvalue.rdata")
genotype <- as.matrix(merged_data_i) 

## CTNNB1 binary trait
response <- somatic_driver_order[,"CTNNB1"]

## fisher exact test to find significant snps that are associated with somatic mutation outcome
mtx_pval <- matrix(0, nrow = length(driver), ncol = dim(merged_data_i)[2])
for (i in 1:length(driver)){
  for (k in 1:dim(merged_data_i)[2]){
    ### create 2 by 3 fisher table
    table_data <- cbind(merged_data_i[,k],somatic_driver_order[,i])
    table23 <- as.matrix(t(table(as.data.frame(table_data))))
    # colnames(table23) <- c("0","1","2")
    # rownames(table23) <- c(0,1)
    
    ### perform fisher exact test 
    model <- fisher.test(table23)
    mtx_pval[i,k] <- model$p.value
  }
}
pval = data.frame(mtx_pval)
rownames(pval) = colnames(somatic_driver_order)
colnames(pval) = colnames(merged_data_i)

fdr <- matrix(p.adjust(as.vector(as.matrix(pval)), method='fdr'),ncol=dim(merged_data_i)[2])
rownames(fdr) = colnames(somatic_driver_order)
colnames(fdr) = colnames(merged_data_i)

sum(fdr["CTNNB1",]<0.05)
which(fdr["CTNNB1",]<0.05)  ## rs62075782

genotype_sel = as.matrix(merged_data_i[,which(fdr["CTNNB1",]<0.05)])
#genotype_sel = as.matrix(merged_data_i)
model <- glm(response~genotype_sel, family = binomial)
model_summary = summary(model)

coefs = model_summary$coefficients
significant_estimates = coefs[coefs[,"Pr(>|z|)"]<0.05,"Estimate"]

par(mar=c(5,5,2,2))
plot(significant_estimates[-1],xlab = "Index of SNPs", ylab = "Estimate of coefficient",
     cex.axis=1.5,cex.lab=1.5,cex.main=1.5, ylim = c(0,2))
abline(a=0, b=0, col="red", lty=1)

