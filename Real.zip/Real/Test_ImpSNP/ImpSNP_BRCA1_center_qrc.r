library(gplots)
library(varhandle)

setwd("D:/Work/lowrank/Rcode/aSPULR")
source("qrc.R")
source("rsvd.R")
source("aSPU0.R")
source("aSPUboot20.R")

setwd("D:/Work/data/2019-5-8aSPUpvalues")

## get SNP matrix A
load("2019-5-8-germlineBRCA1-somaticDriver-association-pvalue.rdata")

driver1 = sort(driver)
somatic_driver_order1 = somatic_driver_order[,order(names(somatic_driver_order))]

nsubject=dim(merged_data_i)[1]
nperm=10000

r = floor(min(dim(merged_data_i))/5)
k = 2

X = merged_data_i

## get Q, R from X
rqr = rsvd(as.matrix(X),r,k)
Q = rqr$Q
R = rqr$R

## center X 
Xc = scale(X, center = TRUE, scale = FALSE)  ## centered X

n = dim(X)[1]
Xm = colMeans(X)  ## column mean vector
Xc1 = qrc(Q,R,Xm,n)  ## get circle Q and circle R (for centered X) from Q and R (for X)
Qc = Xc1$Qc
Rc = Xc1$Rc

## check factorization accuracy 
norm((Xc - Qc%*%Rc),"2")/norm(Xc,"2")
norm((X-Q%*%R),"2")/norm(X,"2") 

qrcc = rsvd(Xc,20,2)
Qcc = qrcc$Q
Rcc = qrcc$R
norm((Xc - Qcc%*%Rcc),"2")/norm(Xc,"2") 
##

out0 = qr(Rc, LAPACK=TRUE)
idx = out0$pivot[1:r]
sort(idx)
sel_snp = colnames(Xc[,idx])

## fisher exact test to find significant snps that are associated with somatic mutation outcome
mtx_pval <- matrix(0, nrow = length(driver1), ncol = dim(Xc)[2])
for (i in 1:length(driver1)){
  for (k in 1:dim(Xc)[2]){
    ### create 2 by 3 fisher table
    table_data <- cbind(Xc[,k],somatic_driver_order1[,i])
    table23 <- as.matrix(t(table(as.data.frame(table_data))))
    # colnames(table23) <- c("0","1","2")
    # rownames(table23) <- c(0,1)
    
    ### perform fisher exact test 
    model <- fisher.test(table23)
    mtx_pval[i,k] <- model$p.value
  }
}
pval = data.frame(mtx_pval)
rownames(pval) = colnames(somatic_driver_order1)
colnames(pval) = colnames(Xc)

##################################### p-values: Heatmap 
## only include genes whose frequency is greater or equal to 1% (57genes)
## select genes 
gene_freq001 <- read.csv("2019-5-12-driver-gene-freq001.csv")
gene_freq001 <- gene_freq001[,-1]
#gene_freq001 <- unfactor(gene_freq001)

pval_freq001 <- pval[which(rownames(pval) %in% gene_freq001),]  
pval_freq001_mtx <- as.matrix(pval_freq001)
pval_freq001_mtx1 <- -log10(pval_freq001_mtx)

lwid = c(0.1,2)
lhei = c(1.5,12,4)
lmat = rbind(c(0,3),c(2,1),c(0,4))

pdf(file = "2025-4-19-center-BRCA1germline-somatic-association-pvalues.pdf", 20, 17)
heatmap.2(pval_freq001_mtx1,col=bluered(100),margin=c(8, 12),cexCol = 1.6,srtCol = 45,
          dendrogram='none', Rowv=FALSE, Colv=FALSE,trace='none',cexRow=1.8,lmat = lmat, lwid = lwid, lhei = lhei, keysize=1, key.par = list(cex=1.2))  ##  Colv: do not reorder column
dev.off()

pval_freq001_mtx1_rsvd = pval_freq001_mtx1[,which(colnames(pval_freq001_mtx1) %in%sel_snp)]

pdf(file = "2025-4-19-center-BRCA1germline-rsvd10-somatic-association-pvalues.pdf", 20, 17)
heatmap.2(pval_freq001_mtx1_rsvd,col=bluered(100),margin=c(8, 12),cexCol = 1.6,srtCol = 45,
          dendrogram='none', Rowv=FALSE, Colv=FALSE,trace='none',cexRow=1.8,lmat = lmat, lwid = lwid, lhei = lhei, keysize=1, key.par = list(cex=1.2))  ##  Colv: do not reorder column
dev.off()

############################## FDR #############################################
fdr <- matrix(p.adjust(as.vector(as.matrix(pval)), method='fdr'),ncol=dim(Xc)[2])
rownames(fdr) = colnames(somatic_driver_order1)
colnames(fdr) = colnames(Xc)

fdr_freq001 <- fdr[which(rownames(fdr) %in% gene_freq001),]  
fdr_freq001_mtx <- as.matrix(fdr_freq001)
fdr_freq001_mtx1 <- -log10(fdr_freq001_mtx)

pdf(file = "2025-4-19-center-BRCA1germline-somatic-association-fdr.pdf", 30, 25)
heatmap.2(fdr_freq001_mtx1,col=bluered(100),margin=c(20, 12),cexCol = 1.6,srtCol = 45,
          dendrogram='none', Rowv=FALSE, Colv=FALSE,trace='none',cexRow=1.8,
          lmat = lmat, lwid = lwid, lhei = lhei, 
          keysize=1, key.par = list(cex=2))  ##  Colv: do not reorder column
dev.off()

fdr_freq001_mtx1_rsvd = fdr_freq001_mtx1[,which(colnames(fdr_freq001_mtx1) %in%sel_snp)]

pdf(file = "2025-4-19-center-BRCA1germline-rsvd10-somatic-association-fdr.pdf", 20, 20)
heatmap.2(fdr_freq001_mtx1_rsvd,col=bluered(100),margin=c(16, 12),cexCol = 1.6,srtCol = 45,
          dendrogram='none', Rowv=FALSE, Colv=FALSE,trace='none',cexRow=1.8,
          lmat = lmat, lwid = lwid, lhei = lhei, 
          keysize=1, key.par = list(cex=2))  ##  Colv: do not reorder column
dev.off()


########## aSPU with selected SNPs vs full SNPs

g0 = c(1:8,Inf)

pvaspu <- c()
pvaspusel <- c()
for (j in 1:length(driver)){
  if (j %% 10 == 0) {message (j,'   ',date())}
  
  Y = somatic_driver_order[,j]
  
  YY = matrix(NA,nsubject,nperm)
  Ym = Y-mean(Y)
  for (b in 1:nperm) YY[,b] = sample(Ym, nsubject)
  
  ###### aSPU with full SNPs
  out0 <- aSPU0(Y, YY, X, cov = NULL, resample = "boot",model = "binomial", pow = g0, n.perm = nperm)
  pvaspu[j] <- out0$pvs[length(out0$pvs)]
  
  ###### aSPU with selected SNPs
  X1 = as.matrix(X[,idx])
  out1 <- aSPU0(Y, YY, X1, cov = NULL, resample = "boot",model = "binomial", pow = g0, n.perm = nperm)
  pvaspusel[j] <- out1$pvs[length(out1$pvs)]
}
df = data.frame(driver,pvaspu,pvaspusel)
df_order = df[order(df$pvaspu),]

## plot
plot(-log10(pvaspu),-log10(pvaspusel), xlab = "Full SNP matrix", ylab = "Selected SNP matrix",
     cex.axis=1.5,cex.lab=1.5,cex.main=1.5)
abline(a=0, b=1, col="red", lty=1)

par(mar=c(5,5,2,2))
qqplot(-log10(pvaspu),-log10(pvaspusel),xlab = "Full SNP matrix", ylab = "Selected SNP matrix",
       cex.axis=1.5,cex.lab=1.5,cex.main=1.5)
#abline(lm((-log10(pvaspu))~(-log10(pvaspusel))),col="red")
abline(a=0, b=1, col="red", lty=1)