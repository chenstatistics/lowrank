simPathAR1Snp2<-function(nGenes=10, nGenes1=5, nSNPs=NULL, ncSNPs = NULL,
                         nSNPlim=c(1,20), nSNP0=1:3, LOR=0.3,
                         n=100, MAFlim=c(0.05, 0.4), rholim=c(0, 0),
                         p0=0.05, noncausal = FALSE){
  
  if (is.null(nSNPs)) nSNPs=sample(nSNPlim[1]:nSNPlim[2], nGenes, replace=T)
  if (is.null(ncSNPs)) ncSNPs=pmin(nSNPs[1:nGenes1], sample(nSNP0, nGenes1, replace=T) )
  ## total # of SNPs:
  q<-sum(nSNPs)
  
  rhos=runif(nGenes, rholim[1], rholim[2])
  
  ###get the overall corr matrix for the laten var's:
  R<-matrix(0, nrow=q, ncol=q)
  for(iGene in 1:nGenes){
    if(iGene==1) Rstart=0 else Rstart=sum(nSNPs[1:(iGene-1)])
    for(i in 1:nSNPs[iGene])
      for(j in 1:nSNPs[iGene])
        R[Rstart+i, Rstart+j]<-rhos[iGene]^(abs(i-j))
  }
  svd.R<-svd(R)
  R1<-svd.R$u %*% diag(sqrt(svd.R$d))
  #R2<- diag(sqrt(svd.R$d)) %*% t(svd.R$v)
  #Note above: R1 %*% t(R1)= R
  
  ##background disease prev:
  b0<-log(p0/(1-p0))
  ##LOR:
  b1<-rep(0, q)
  for(i in 1:nGenes1)
    if (i==1) b1[1:ncSNPs[1]]=LOR  else b1[sum(nSNPs[1:(i-1)])+(1:ncSNPs[i])]=LOR
  
  MAFs<-runif(q, MAFlim[1], MAFlim[2])
  cutoff<-qnorm(MAFs)
  
  X<-matrix(0, nrow=n, ncol=q)
  Y<-rep(0, n);
  i<-1
  #sampling controls:
  while ( i <= n){
    X0<-rnorm(q, 0, 1) #: X0 ~ MVN(0, I)
    X1<-R1 %*% X0   #: X1 ~ MVN(0, R)
    X2<-ifelse(X1<cutoff, 1, 0)
    X0<-rnorm(q, 0, 1) #: X0 ~ MVN(0, I)
    X1<-R1 %*% X0   #: X1 ~ MVN(0, R)
    X3<-ifelse(X1<cutoff, 1, 0)
    X4<-X2+ X3
    pr<-1/(1 + exp(-(b0 + sum(b1 * X4))))
    Y1<-sample(c(0, 1), 1, prob=c(1-pr, pr))
    Y[i]=Y1
    X[i, ]<-X4
    i<-i+1
  }
  # #sampling cases:
  # while ( i <= 2*n){
  #   X0<-rnorm(q, 0, 1) #: X0 ~ MVN(0, I)
  #   X1<-R1 %*% X0   #: X1 ~ MVN(0, R)
  #   X2<-ifelse(X1<cutoff, 1, 0)
  #   X0<-rnorm(q, 0, 1) #: X0 ~ MVN(0, I)
  #   X1<-R1 %*% X0   #: X1 ~ MVN(0, R)
  #   X3<-ifelse(X1<cutoff, 1, 0)
  #   X4<-X2+ X3
  #   pr<-1/(1 + exp(-(b0 + sum(b1 * X4))))
  #   Y1<-sample(c(0, 1), 1, prob=c(1-pr, pr))
  #   if (Y1==1){
  #     X[i, ]<-X4
  #     i<-i+1
  #   }
  # }
  
  if ( noncausal == FALSE ) {
    snp.chrom=snp.loc=NULL
    for(i in 1:nGenes){
      snp.chrom=c(snp.chrom, rep(i, nSNPs[i]))
      snp.loc=c(snp.loc, 1:nSNPs[i])
    }
    snp.info = cbind(1:q, snp.chrom, snp.loc)
    gene.info=cbind(1:nGenes, 1:nGenes, rep(0, nGenes), nSNPs)
    pathway = list(pathway1=as.character(1:nGenes))
    
    return( list(Y=Y, X=X, snp.info=snp.info, gene.info=gene.info,
                 pathway=pathway, nSNPs=nSNPs) )
  } else { ## exclude causal SNPs
    X = X[, abs(b1)<1e-10]
    
    snp.chrom=snp.loc=NULL
    for(i in 1:nGenes1){
      snp.chrom=c(snp.chrom, rep(i, nSNPs[i]-ncSNPs[i]))
      if (nSNPs[i]-ncSNPs[i]>=1)
        snp.loc=c(snp.loc, 1:(nSNPs[i]-ncSNPs[i]))
    }
    if (nGenes1 < nGenes){
      for(i in (nGenes1+1):nGenes){
        snp.chrom=c(snp.chrom, rep(i, nSNPs[i]))
        snp.loc=c(snp.loc, 1:nSNPs[i])
      }
    }
    snp.info = cbind(1:(q-sum(ncSNPs)), snp.chrom, snp.loc)
    nSNPsNone0=nSNPs
    for(i in 1:nGenes1)
      nSNPsNone0[i] = nSNPs[i]-ncSNPs[i]
    gene.info=cbind(1:nGenes, 1:nGenes, rep(0, nGenes), nSNPsNone0)
    pathway = list(pathway1=as.character(1:nGenes))
    
    return ( list(Y=Y, X=X, snp.info=snp.info, gene.info=gene.info,
                  pathway=pathway, nSNPs=nSNPsNone0) )
  }
  
  
}