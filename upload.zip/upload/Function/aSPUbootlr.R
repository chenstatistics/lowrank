aSPUbootlr = function (Y, YY, X, tQ, tR, cov = NULL, model = c("gaussian", "binomial"), 
          pow = c(1:8, Inf), n.perm = 1000) 
{
  # time01 = Sys.time()
  model <- match.arg(model)
  n <- length(Y)
  if (is.null(X) && length(X) > 0) 
    X = as.matrix(X, ncol = 1)
  k <- ncol(X)
  if (is.null(cov)) {
    #Xg <- X
    #tXg = t(Xg)
    
    #r = 400
    #Xt = rsvd(as.matrix(tXg),r)
    #tQ = t(Q)
    #tR = t(R)
    
    U <- tR %*% (tQ %*% (Y - mean(Y)))
    yresids <- Y - mean(Y)
    yfits <- rep(mean(Y), n)
  }
  else {
    tdat1 <- data.frame(trait = Y, cov)
    if (is.null(colnames(cov))) {
      colnames(tdat1) = c("trait", paste("cov", 1:dim(cov)[2], 
                                         sep = ""))
    }
    else {
      colnames(tdat1) = c("trait", colnames(cov))
    }
    fit1 <- glm(trait ~ ., family = model, data = tdat1)
    yfits <- fitted.values(fit1)
    yresids <- Y - yfits
    Us <- XUs <- matrix(0, nrow = n, ncol = k)
    Xmus = X
    for (i in 1:k) {
      tdat2 <- data.frame(X1 = X[, i], cov)
      fit2 <- glm(X1 ~ ., data = tdat2)
      Xmus[, i] <- fitted.values(fit2)
      XUs[, i] <- (X[, i] - Xmus[, i])
    }
    U <- t(XUs) %*% (Y - yfits)
  }
  # time02 = Sys.time()
  
  Ts <- rep(0, length(pow))
  
  pow = sort(pow)
  for (j in 1:length(pow)) {
    if (pow[j] < Inf) 
    {#Ts[j] = sum(U^pow[j])
      if (pow[j] != j) stop('---------- Error: pow[j] must be j -----------')
      if (j == 1) u1 = U
      else        u1 = u1*U
      Ts[j] = sum(u1) #sum(U0^pow[j])
    }
    else Ts[j] = max(abs(U))
  }
  # time03 = Sys.time()
  
  T0s = matrix(0, nrow = n.perm, ncol = length(pow))
  #Y0 = Y
  
  # t31 = 0
  # t32 = 0
  # t33 = 0

   for (b in 1:n.perm) {
    if (is.null(cov)) {
   #   time030 = Sys.time()
      #Y0 <- sample(Y, length(Y))
      #Y00 = Y0 - mean(Y0)
      Y00 = YY[,b]
   #   time031 = Sys.time()
      #U0 <- t(Xg) %*% (Y0 - mean(Y0))
      #U0 <- tXg %*% Y00
      
      U0 <- tR %*% (tQ %*% Y00)       
      
   #   time032 = Sys.time()
      
   #   t31 = t31+time031-time030
   #   t32 = t32+time032-time031
    }
    else {
      if (model == "gaussian") {
        Y0 <- yfits + sample(yresids, n, replace = F)
        tdat0 <- data.frame(trait = Y0, cov)
        fit0 <- glm(trait ~ ., data = tdat0)
        yfits0 <- fitted.values(fit0)
        U0 <- t(XUs) %*% (Y0 - yfits0)
      }
      else {
        for (i in 1:n) Y0[i] <- sample(c(1, 0), 1, prob = c(yfits[i], 
                                                            1 - yfits[i]))
        tdat0 <- data.frame(trait = Y0, cov)
        fit0 <- glm(trait ~ ., family = model, data = tdat0)
        yfits0 <- fitted.values(fit0)
        U0 <- t(XUs) %*% (Y0 - yfits0)
      }
    }
    
   # time033 = Sys.time()
    for (j in 1:length(pow))
    {if (pow[j] < Inf) 
      {
      if (j == 1) u1 = U0 #{for (k1 in 1:pow[j]) u1 = u1*U0}
      else        u1 = u1*U0
      #{if (pow[j-1] == pow[j]) errorCondition('error')
      # for (k1 in pow[j-1]+1:pow[j]) u1 = u1*U0}
      T0s[b, j] = sum(u1) #sum(U0^pow[j])
      }
      else T0s[b, j] = max(abs(U0))
    }
   # time034 = Sys.time()
   # t33 = t33+time034-time033
  }
  # time04 = Sys.time()
  
  pPerm0 = rep(NA, length(pow))
  for (j in 1:length(pow)) {
    pPerm0[j] = sum(abs(Ts[j]) <= abs(T0s[, j]))/n.perm  
    P0s = ((n.perm - rank(abs(T0s[, j]))) + 1)/(n.perm) 
    if (j == 1) 
      minp0 = P0s
    else minp0[which(minp0 > P0s)] = P0s[which(minp0 > P0s)]
  }
  # time05 = Sys.time()
  
  Paspu <- (sum(minp0 <= min(pPerm0)) + 1)/(n.perm + 1) 
  pvs <- c(pPerm0, Paspu)
  Ts <- c(Ts, min(pPerm0))
  names(Ts) <- c(paste("SPU", pow, sep = ""), "aSPU")
  names(pvs) = names(Ts)
  
  # time06 = Sys.time()
  # 
  # t1 = time02-time01
  # t2 = time03-time02
  # t3 = time04-time03
  # t4 = time05-time04
  # t5 = time06-time05
  
  # t = c(t1,t2,t3,t4,t5,t31,t32,t33)
  # names(t) = c("t1","t2","t3","t4","t5","t31","t32","t33")
  # list(Ts = Ts, pvs = pvs, time = t)

  list(Ts = Ts, pvs = pvs)
}
