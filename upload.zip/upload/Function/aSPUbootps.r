aSPUbootps <- function (Y, YY, X, cov = NULL, model = c("gaussian", "binomial"), 
          pow, n.perm = 1000) 
{
  model <- match.arg(model)
  n <- length(Y)
  if (is.null(X) && length(X) > 0) 
    X = as.matrix(X, ncol = 1)
  k <- ncol(X)
  if (is.null(cov)) {
    Xg <- X
    tXg = t(Xg)
    
    U <- tXg %*% (Y - mean(Y))
    yresids <- Y - mean(Y)
    yfits <- rep(mean(Y), n)
  }
  else {
    tdat1 <- data.frame(trait = Y, cov)
    if (is.null(colnames(cov))) {
      colnames(tdat1) = c("trait", paste("cov", 1:dim(cov)[2], 
                                         sep = ""))
    }
    else {
      colnames(tdat1) = c("trait", colnames(cov))
    }
    fit1 <- glm(trait ~ ., family = model, data = tdat1)
    yfits <- fitted.values(fit1)
    yresids <- Y - yfits
    Us <- XUs <- matrix(0, nrow = n, ncol = k)
    Xmus = X
    for (i in 1:k) {
      tdat2 <- data.frame(X1 = X[, i], cov)
      fit2 <- glm(X1 ~ ., data = tdat2)
      Xmus[, i] <- fitted.values(fit2)
      XUs[, i] <- (X[, i] - Xmus[, i])
    }
    U <- t(XUs) %*% (Y - yfits)
  }
  Ts <- rep(0, length(pow))

  pow = sort(pow)
  for (j in 1:length(pow)) {
    if (pow[j] < Inf) 
    {#Ts[j] = sum(U^pow[j])
      if (pow[j] != j) stop('---------- Error: pow[j] must be j -----------')
      if (j == 1) u1 = U
      else        u1 = u1*U
      Ts[j] = sum(u1) #sum(U0^pow[j])
    }
    else Ts[j] = max(abs(U))
  }
  T0s = matrix(0, nrow = n.perm, ncol = length(pow))
  #Y0 = Y
  
  for (b in 1:n.perm) {
    if (is.null(cov)) {
      Y00 = YY[,b]
      #   time031 = Sys.time()
      U0 <- tXg %*% Y00
    }
    else {
      if (model == "gaussian") {
        Y0 <- yfits + sample(yresids, n, replace = F)
        tdat0 <- data.frame(trait = Y0, cov)
        fit0 <- glm(trait ~ ., data = tdat0)
        yfits0 <- fitted.values(fit0)
        U0 <- t(XUs) %*% (Y0 - yfits0)
      }
      else {
        for (i in 1:n) Y0[i] <- sample(c(1, 0), 1, prob = c(yfits[i], 
                                                            1 - yfits[i]))
        tdat0 <- data.frame(trait = Y0, cov)
        fit0 <- glm(trait ~ ., family = model, data = tdat0)
        yfits0 <- fitted.values(fit0)
        U0 <- t(XUs) %*% (Y0 - yfits0)
      }
    }
    for (j in 1:length(pow))
      {if (pow[j] < Inf) 
        {
         if (j == 1) u1 = U0 #{for (k in 1:pow[j]) u1 = u1*U0}
         else        u1 = u1*U0
         T0s[b, j] = sum(u1) #sum(U0^pow[j])
        }
       else T0s[b, j] = max(abs(U0))
      }
  }
  pPerm0 = rep(NA, length(pow))
  imin = rep(0,n.perm)
  nmin0 = rep(0,length(pow))
  nmin = rep(0,length(pow))
  minp0 = rep(1,n.perm)

  igamma = 0
  pgamma = 9999
  for (j in 1:length(pow)) {
    pPerm0[j] = sum(abs(Ts[j]) <= abs(T0s[, j]))/n.perm

    if (pgamma > pPerm0[j])
    {
      pgamma = pPerm0[j]
      igamma = j
    }
    P0s = ((n.perm - rank(abs(T0s[, j]))) + 1)/(n.perm)
    #if (j == 1) 
    #  minp0 = P0s
    #else 
    nmin0[j] = length(which(minp0 > P0s))
    minp0[which(minp0 > P0s)] = P0s[which(minp0 > P0s)]
    for (k in 1:n.perm)
    {
      if (minp0[k] == P0s[k]) imin[k] = j
    }
  }
  
  
  for (k in 1:n.perm)
  {
    nmin[imin[k]] = nmin[imin[k]]+1
  }
  Paspu <- (sum(minp0 <= min(pPerm0)) + 1)/(n.perm + 1)
  #message('Paspu: ',Paspu)
  pvs <- c(pPerm0, Paspu)
  Ts <- c(Ts, min(pPerm0))
  names(Ts) <- c(paste("SPU", pow, sep = ""), "aSPU")
  names(pvs) = names(Ts)
  list(Ts = Ts, pvs = pvs, igamma = igamma)
}