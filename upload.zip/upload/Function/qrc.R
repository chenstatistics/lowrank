qrc = function(Q,R,Xm,n){
  qvec = t(Q)%*%rep(1,n)
  qt = 1-(Q%*%qvec)
  qtn = norm(qt,"2")
  q = qt/qtn
  Qc = cbind(Q,q)
  R1 = R-qvec%*%t(Xm)
  R2 = -qtn*t(Xm)
  Rc = rbind(R1,R2)
  Xc1 = list(Qc=Qc,Rc=Rc)
  return(Xc1)
}