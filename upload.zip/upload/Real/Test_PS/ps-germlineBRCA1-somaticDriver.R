library("aSPU")
setwd("D:/Work/lowrank/Rcode/aSPULR")
source("aSPU0ps.r")
source("aSPUbootps.r")
source("rsvd.R")
source("aSPUbootlrps.r")

setwd("D:/Work/data/2019-5-8aSPUpvalues")
load("2019-5-8-germlineBRCA1-somaticDriver-association-pvalue.rdata")

nshuff = 1000
nperm = 1000
nsubject = 2049 ## 2049: 80% samples (total sample: 2561)

g = c(1:32,Inf)

pvaspu1 <- c()
pvaspu2 <- c()
nmin1 = rep(0,length(g))
nmin2 = rep(0,length(g))
for (j in 1:nshuff){
  if (j %% 10 == 0) {message (j,'   ',date())}
  
  # random shuffling
  rows <- sample(nrow(merged_data_i))
  X_data <- merged_data_i[rows, ]
  Y_data <- somatic_driver_order[rows,"CTNNB1"]
  
  X = X_data[1:2049,]  ## 2049 Subset sampling 80% (total sample: 2561)
  Y = Y_data[1:2049]

  YY = matrix(NA,nsubject,nperm)
  Ym = Y-mean(Y)
  for (b in 1:nperm) YY[,b] = sample(Ym, nsubject)
  
  ##### aSPU #####  
  out1 <- aSPU0ps(Y, YY, X, cov = NULL, resample = "boot",model = "binomial", pow = g, n.perm = nperm)
  pvaspu1[j] <- out1$pvs[length(out1$pvs)]
  igamma1 <- out1$igamma
  
  ##### aSPU-LR #####
  r <- 10
  Xt = rsvd(as.matrix(X),r,k=2)
  out2 <- aSPUbootlrps(Y, YY, t(Xt$Q), t(Xt$R), cov = NULL, pow = g, n.perm = nperm, model = "binomial")
  
  pvaspu2[j] <- out2$pvs[length(out1$pvs)]
  igamma2 <- out2$igamma
  
  nmin1[igamma1] = nmin1[igamma1]+1
  nmin2[igamma2] = nmin2[igamma2]+1
}  
par(mar=c(5,5,2,2))
matplot(1:length(nmin1),cbind(nmin1,nmin2),type="b",pch=1:2, col=1:2, 
        xlab = expression("Index of " *gamma*""), ylab = expression(rho[gamma]), cex=2, cex.axis=2,cex.lab=2,cex.main=2)
legend("topright", inset=0.1, legend=c("Original X","Approximate X"), col=c(1:2),
       pch=1:2,bg= ("white"), horiz=F,cex=2,bty="n")

