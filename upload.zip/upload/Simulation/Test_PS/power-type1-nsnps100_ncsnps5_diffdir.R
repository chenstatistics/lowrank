library("aSPU")
setwd("D:/Work/lowrank/Rcode/aSPULR")
source("aSPUlr.R")
source("aSPUbootlr.R")
source("aSPU0.R")
source("aSPUboot20.R")
source("aSPUboot20anyg.R")
source("rsvd.R")
source("simPathAR1Snp2.r")

set.seed(100)

nsnps = c(100)

nsim = 1000
nperm = 1000

nsubject = 500
ncgene = 1
rhos = c(0.8, 0.9)
p0 = 0.1

ngene = 1
# ncsnps = c(rep(10,ncgene),rep(0, ngene-ncgene))
ncsnps = 5

g0 = c(1:32,Inf)
g1 = c(2)

logor = c(2.0,-2.0,2.0,-2.0,2.0) ## to calculate power
#logor = 0                         ## to calculate type 1 error

pwaspu <- c()
pwaspups <- c()
pwaspulrps <- c()
# for (i in 1:6){
for (i in 1:1){
  pvaspu <- c()
  pvaspups <- c()
  pvaspulrps <- c()
  for (j in 1:nsim){
    if (j %% 10 == 0) {message (i,': ', j,'   ',date())}
    dat1 <- simPathAR1Snp2(nGenes = ngene, nGenes1 = ncgene, nSNPs = nsnps, ncSNPs = ncsnps,
                           nSNPlim = c(1, ngene), nSNP0 = 1, LOR = logor, n = nsubject,
                           MAFlim = c(0.05, 0.4), rholim = rhos, p0 = p0, noncausal = FALSE)
    
    YY = matrix(NA,nsubject,nperm)
    Ym = dat1$Y-mean(dat1$Y)
    for (b in 1:nperm) YY[,b] = sample(Ym, nsubject)
    
    ###### aSPU #####
    out0 <- aSPU0(dat1$Y, YY, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = g0, n.perm = nperm)
    pvaspu[j] <- out0$pvs[length(out0$pvs)]
    
    ###### aSPU-PS #####
    #out1 <- aSPU0(dat1$Y, YY, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = g1, n.perm = nperm)
    out1 <- aSPUboot20anyg(dat1$Y, YY, dat1$X, cov = NULL, model = "binomial", pow = g1, n.perm = nperm)
    pvaspups[j] <- out1$pvs[length(out1$pvs)]

  }
  pwaspu[i] <- sum(pvaspu < 0.05)/length(pvaspu)
  pwaspups[i] <- sum(pvaspups < 0.05)/length(pvaspups)
}

