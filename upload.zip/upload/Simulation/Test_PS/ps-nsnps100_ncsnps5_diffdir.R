library("aSPU")
setwd("D:/Work/lowrank/Rcode/aSPULR")
source("aSPU0ps.r")
source("aSPUbootps.r")
source("rsvd.R")
source("aSPUbootlrps.r")
source("simPathAR1Snp2.r")

set.seed(100)

nsnps = c(100)

nsim = 1000
nperm = 1000

nsubject = 500
ncgene = 1
rhos = c(0.8, 0.9)
p0 = 0.1

ngene = 1
ncsnps = 5

g = c(1:32,Inf)

logor = c(2.0,-2.0,2.0,-2.0,2.0)

pvaspu1 <- c()
pvaspu2 <- c()
nmin1 = rep(0,length(g))
nmin2 = rep(0,length(g))

for (j in 1:nsim){
  if (j %% 10 == 0) {message (j,'   ',date())}
  #ncsnps = c(rep(1,ncgene[i]),rep(0, ngene-ncgene[i]))
  dat1 <- simPathAR1Snp2(nGenes = ngene, nGenes1 = ncgene, nSNPs = nsnps, ncSNPs = ncsnps,
                         nSNPlim = c(1, ngene), nSNP0 = 1, LOR = logor, n = nsubject,
                         MAFlim = c(0.05, 0.4), rholim = rhos, p0 = p0, noncausal = FALSE)

  YY = matrix(NA,nsubject,nperm)
  Ym = dat1$Y-mean(dat1$Y)
  for (b in 1:nperm) YY[,b] = sample(Ym, nsubject)
  
  ##### aSPU #####  
  out1 <- aSPU0ps(dat1$Y, YY, dat1$X, cov = NULL, resample = "boot",model = "binomial", pow = g, n.perm = nperm)
  pvaspu1[j] <- out1$pvs[length(out1$pvs)]
  igamma1 <- out1$igamma
  
  ##### aSPU-LR #####
  r <- 10
  Xt = rsvd(dat1$X,r,k=2)
  out2 <- aSPUbootlrps(dat1$Y, YY, t(Xt$Q), t(Xt$R), cov = NULL, pow = g, n.perm = nperm, model = "binomial")

  pvaspu2[j] <- out2$pvs[length(out1$pvs)]
  igamma2 <- out2$igamma

  nmin1[igamma1] = nmin1[igamma1]+1
  nmin2[igamma2] = nmin2[igamma2]+1
}  

par(mar=c(5,5,2,2))
matplot(1:length(nmin1),cbind(nmin1,nmin2),type="b",pch=1:2, col=1:2, xlab = expression("Index of " *gamma*""), ylab = expression(rho[gamma]), cex=2, cex.axis=2,cex.lab=2,cex.main=2)
legend("topright", inset=0.1, legend=c("Original X","Approximate X"), col=c(1:2),pch=1:2,bg= ("white"), horiz=F,cex=2,bty="n")

