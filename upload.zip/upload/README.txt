This package is designed "as is" for the authors' own academic research/
test uses, and is NOT for other purposes. It is not yet released to the 
public. Please do not redistribute.

Other packages may be used. The copyright belongs to their respective
authors/owners.

The authors do not warrant that any functions contained in this package
will meet the user's requirements, or will be error free. The entire 
risk as to the performance and/or quality of the package is solely with 
the user and not the authors.

The user assumes responsibility for the use of the software to achieve
intended results. In no event shall the authors be liable for any defect
in the package or any damages (direct, indirect, incidental, special, 
exemplary, consequential, etc.) however caused arising in any way out 
of the use of this package, even if advised of the possibility of such
damages.

The codes were originally developped by Zhongyuan Chen. The 
routines may not be well optimized or documented. For questions and
suggestions, please contact the authors.



